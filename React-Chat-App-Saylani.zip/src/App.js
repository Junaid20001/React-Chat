import AppRouter from './config/Router'

function App() {
  return (
    <AppRouter />
  );
}

export default App;
