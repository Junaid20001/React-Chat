import './App.css';
import { useState, useMemo } from 'react';
import Header from './header'
function App() {
  const [count, setCount] = useState(0);
  const [myCount, setMyCount] = useState(0);

  const get_data = useMemo(() => {
    return myCount * 5
  }, [myCount])

  const myheader = useMemo(() => {
    return <Header />
  }, [])

  return (
    <div className="App">
      {myheader}
      {/* <Header /> */}
      <h1>Use Memo</h1>
      <h2>Count: {count}</h2>
      <h2>myCount: {myCount}</h2>
      <h2>get_data: {get_data}</h2>
      <button onClick={() => setCount(count + 1)}>update count</button>
      <br />
      <button onClick={() => setMyCount(myCount + 1)}>update myCount</button>
    </div>
  );
}

export default App;
