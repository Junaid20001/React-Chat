import { useMemo } from 'react'

function Header() {
    console.log("I'm header")
    return (
        <h1>Header</h1>
    )
}


export default Header;